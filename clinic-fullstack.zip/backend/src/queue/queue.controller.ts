import { Body, Controller, Get, Param, Patch, Post, UseGuards } from '@nestjs/common';
import { QueueService } from './queue.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { QueueStatus } from './queue-item.entity';

@UseGuards(JwtAuthGuard)
@Controller('queue')
export class QueueController {
  constructor(private readonly queueService: QueueService) {}

  @Get()
  list() {
    return this.queueService.list();
  }

  @Post()
  add(@Body() body: { patient: any; doctorId?: string }) {
    return this.queueService.add(body.patient, body.doctorId);
  }

  @Patch(':id/status')
  updateStatus(@Param('id') id: string, @Body() body: { status: QueueStatus }) {
    return this.queueService.updateStatus(id, body.status);
  }
}
