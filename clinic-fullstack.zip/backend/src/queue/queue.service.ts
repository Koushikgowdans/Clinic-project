import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { QueueItem, QueueStatus } from './queue-item.entity';
import { Patient } from '../patients/patient.entity';
import { Doctor } from '../doctors/doctor.entity';

@Injectable()
export class QueueService {
  constructor(
    @InjectRepository(QueueItem) private queueRepo: Repository<QueueItem>,
    @InjectRepository(Patient) private patientRepo: Repository<Patient>,
    @InjectRepository(Doctor) private doctorRepo: Repository<Doctor>
  ) {}

  async add(patientData: Partial<Patient>, doctorId?: string) {
    let patient = await this.patientRepo.findOne({ where: { email: patientData.email } });
    if (!patient) {
      patient = this.patientRepo.create(patientData);
      await this.patientRepo.save(patient);
    }
    const queueNumber = (await this.queueRepo.count()) + 1;
    const doctor = doctorId ? await this.doctorRepo.findOne({ where: { id: doctorId } }) : null;
    const item = this.queueRepo.create({ patient, doctor, queueNumber });
    return this.queueRepo.save(item);
  }

  list() {
    return this.queueRepo.find({ order: { queueNumber: 'ASC' } });
  }

  async updateStatus(id: string, status: QueueStatus) {
    const item = await this.queueRepo.findOne({ where: { id } });
    if (!item) throw new NotFoundException('Queue item not found');
    item.status = status;
    return this.queueRepo.save(item);
  }
}
