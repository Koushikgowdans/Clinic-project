import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { QueueItem } from './queue-item.entity';
import { QueueService } from './queue.service';
import { QueueController } from './queue.controller';
import { Patient } from '../patients/patient.entity';
import { Doctor } from '../doctors/doctor.entity';

@Module({
  imports: [TypeOrmModule.forFeature([QueueItem, Patient, Doctor])],
  providers: [QueueService],
  controllers: [QueueController],
})
export class QueueModule {}
