import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, ManyToOne, JoinColumn } from 'typeorm';
import { Patient } from '../patients/patient.entity';
import { Doctor } from '../doctors/doctor.entity';

export enum QueueStatus {
  WAITING = 'WAITING',
  WITH_DOCTOR = 'WITH_DOCTOR',
  COMPLETED = 'COMPLETED',
  SKIPPED = 'SKIPPED'
}

@Entity()
export class QueueItem {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @ManyToOne(() => Patient, { eager: true, cascade: true })
  @JoinColumn()
  patient: Patient;

  @ManyToOne(() => Doctor, { nullable: true, eager: true })
  @JoinColumn()
  doctor: Doctor;

  @Column()
  queueNumber: number;

  @Column({ type: 'enum', enum: QueueStatus, default: QueueStatus.WAITING })
  status: QueueStatus;

  @CreateDateColumn()
  createdAt: Date;
}
