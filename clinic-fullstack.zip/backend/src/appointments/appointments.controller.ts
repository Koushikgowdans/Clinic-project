import { Body, Controller, Get, Param, Patch, Post, UseGuards } from '@nestjs/common';
import { AppointmentsService } from './appointments.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';

@UseGuards(JwtAuthGuard)
@Controller('appointments')
export class AppointmentsController {
  constructor(private readonly apptService: AppointmentsService) {}

  @Get()
  list() {
    return this.apptService.list();
  }

  @Post('book')
  book(@Body() body: { doctorId: string; patient: any; date: string }) {
    return this.apptService.book(body.doctorId, body.patient, new Date(body.date));
  }

  @Patch(':id/reschedule')
  reschedule(@Param('id') id: string, @Body() body: { date: string }) {
    return this.apptService.reschedule(id, new Date(body.date));
  }

  @Patch(':id/cancel')
  cancel(@Param('id') id: string) {
    return this.apptService.cancel(id);
  }
}
