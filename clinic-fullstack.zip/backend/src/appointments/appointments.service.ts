import { Injectable, BadRequestException, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Appointment, AppointmentStatus } from './appointment.entity';
import { Doctor } from '../doctors/doctor.entity';
import { Patient } from '../patients/patient.entity';

@Injectable()
export class AppointmentsService {
  constructor(
    @InjectRepository(Appointment) private apptRepo: Repository<Appointment>,
    @InjectRepository(Doctor) private doctorRepo: Repository<Doctor>,
    @InjectRepository(Patient) private patientRepo: Repository<Patient>
  ) {}

  async book(doctorId: string, patientData: Partial<Patient>, date: Date) {
    const doctor = await this.doctorRepo.findOne({ where: { id: doctorId } });
    if (!doctor) throw new NotFoundException('Doctor not found');
    let patient = await this.patientRepo.findOne({ where: { email: patientData.email } });
    if (!patient) {
      patient = this.patientRepo.create(patientData);
      await this.patientRepo.save(patient);
    }
    const appt = this.apptRepo.create({ doctor, patient, appointmentAt: date });
    return this.apptRepo.save(appt);
  }

  async reschedule(id: string, date: Date) {
    const appt = await this.apptRepo.findOne({ where: { id } });
    if (!appt) throw new NotFoundException('Appointment not found');
    appt.appointmentAt = date;
    return this.apptRepo.save(appt);
  }

  async cancel(id: string) {
    const appt = await this.apptRepo.findOne({ where: { id } });
    if (!appt) throw new NotFoundException('Appointment not found');
    appt.status = AppointmentStatus.CANCELED;
    return this.apptRepo.save(appt);
  }

  list() {
    return this.apptRepo.find();
  }
}
