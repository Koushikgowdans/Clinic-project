# Clinic Frontend (Next.js + Tailwind)

## Setup

1. Install dependencies:
   ```bash
   npm install
   ```

2. Set environment variable (create `.env.local`):
   ```
   NEXT_PUBLIC_API_URL=http://localhost:3000
   ```

3. Run dev server:
   ```bash
   npm run dev
   ```

## Notes

- This is a minimal front desk UI that authenticates using the backend created earlier.
- Login uses `/auth/login`. Register via backend `/auth/register` if needed.
