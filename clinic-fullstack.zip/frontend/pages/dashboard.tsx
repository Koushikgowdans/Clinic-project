import Layout from '../components/Layout'
import { useEffect, useState } from 'react'
import axios from 'axios'
import { useRouter } from 'next/router'

type QueueItem = { id: string, queueNumber: number, status: string, patient: any, createdAt: string }

export default function Dashboard() {
  const router = useRouter()
  const [queue, setQueue] = useState<QueueItem[]>([])
  const [patientName, setPatientName] = useState('')
  const [patientEmail, setPatientEmail] = useState('')

  useEffect(()=> {
    const token = localStorage.getItem('token')
    if (!token) router.push('/')
    fetchQueue()
  }, [])

  const api = axios.create({ baseURL: process.env.NEXT_PUBLIC_API_URL, headers: { Authorization: 'Bearer ' + (typeof window !== 'undefined' ? localStorage.getItem('token') : '') } })

  const fetchQueue = async () => {
    const res = await api.get('/queue')
    setQueue(res.data)
  }

  const addWalkIn = async () => {
    await api.post('/queue', { patient: { name: patientName, email: patientEmail } })
    setPatientName(''); setPatientEmail('')
    fetchQueue()
  }

  const updateStatus = async (id: string, status: string) => {
    await api.patch(`/queue/${id}/status`, { status })
    fetchQueue()
  }

  return (
    <Layout>
      <div className="max-w-3xl mx-auto">
        <h1 className="text-xl font-bold mb-4">Queue Management</h1>

        <div className="bg-white p-4 rounded shadow mb-6">
          <h2 className="font-semibold mb-2">Add Walk-in Patient</h2>
          <div className="flex gap-2">
            <input value={patientName} onChange={e=>setPatientName(e.target.value)} placeholder="Name" className="p-2 border rounded flex-1" />
            <input value={patientEmail} onChange={e=>setPatientEmail(e.target.value)} placeholder="Email" className="p-2 border rounded flex-1" />
            <button onClick={addWalkIn} className="px-4 py-2 bg-green-600 text-white rounded">Add</button>
          </div>
        </div>

        <div className="bg-white p-4 rounded shadow">
          <h2 className="font-semibold mb-2">Current Queue</h2>
          <table className="w-full">
            <thead><tr><th>#</th><th>Patient</th><th>Status</th><th>Actions</th></tr></thead>
            <tbody>
              {queue.map(q => (
                <tr key={q.id} className="border-t">
                  <td className="py-2">{q.queueNumber}</td>
                  <td className="py-2">{q.patient?.name || q.patient?.email}</td>
                  <td className="py-2">{q.status}</td>
                  <td className="py-2 space-x-2">
                    <button onClick={()=>updateStatus(q.id, 'WITH_DOCTOR')} className="px-2 py-1 border rounded">With Doctor</button>
                    <button onClick={()=>updateStatus(q.id, 'COMPLETED')} className="px-2 py-1 border rounded">Complete</button>
                    <button onClick={()=>updateStatus(q.id, 'SKIPPED')} className="px-2 py-1 border rounded">Skip</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </Layout>
  )
}
