import { useState } from 'react'
import { useRouter } from 'next/router'
import axios from 'axios'

export default function Login() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const router = useRouter()

  const login = async (e: any) => {
    e.preventDefault()
    setError('')
    try {
      const res = await axios.post(process.env.NEXT_PUBLIC_API_URL + '/auth/login', { email, password })
      if (res.data && res.data.access_token) {
        localStorage.setItem('token', res.data.access_token)
        router.push('/dashboard')
      } else {
        setError('Invalid credentials')
      }
    } catch (err: any) {
      setError(err.response?.data?.message || 'Login failed')
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <div className="max-w-md w-full bg-white p-8 rounded shadow">
        <h1 className="text-2xl font-bold mb-4">Clinic Front Desk — Login</h1>
        <form onSubmit={login} className="space-y-4">
          <input value={email} onChange={e=>setEmail(e.target.value)} placeholder="email" className="w-full p-2 border rounded" />
          <input value={password} onChange={e=>setPassword(e.target.value)} type="password" placeholder="password" className="w-full p-2 border rounded" />
          <button className="w-full p-2 bg-blue-600 text-white rounded">Login</button>
        </form>
        {error && <p className="text-red-600 mt-3">{error}</p>}
        <p className="text-sm text-gray-500 mt-4">Use the backend /auth/register to create a user</p>
      </div>
    </div>
  )
}
