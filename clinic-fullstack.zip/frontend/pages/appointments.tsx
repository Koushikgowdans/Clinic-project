import Layout from '../components/Layout'
import { useEffect, useState } from 'react'
import axios from 'axios'
import { useRouter } from 'next/router'

export default function Appointments() {
  const router = useRouter()
  const [doctors, setDoctors] = useState<any[]>([])
  const [doctorId, setDoctorId] = useState('')
  const [patientName, setPatientName] = useState('')
  const [patientEmail, setPatientEmail] = useState('')
  const [date, setDate] = useState('')

  useEffect(()=> {
    const token = localStorage.getItem('token')
    if (!token) router.push('/')
    fetchDoctors()
  }, [])

  const api = axios.create({ baseURL: process.env.NEXT_PUBLIC_API_URL, headers: { Authorization: 'Bearer ' + (typeof window !== 'undefined' ? localStorage.getItem('token') : '') } })

  const fetchDoctors = async () => {
    const res = await api.get('/doctors')
    setDoctors(res.data)
  }

  const book = async () => {
    await api.post('/appointments/book', { doctorId, patient: { name: patientName, email: patientEmail }, date })
    setPatientName(''); setPatientEmail(''); setDate('')
    alert('Booked')
  }

  return (
    <Layout>
      <div className="max-w-3xl mx-auto">
        <h1 className="text-xl font-bold mb-4">Appointments</h1>

        <div className="bg-white p-4 rounded shadow mb-6">
          <h2 className="font-semibold mb-2">Book Appointment</h2>
          <div className="space-y-2">
            <select value={doctorId} onChange={e=>setDoctorId(e.target.value)} className="w-full p-2 border rounded">
              <option value="">Select doctor</option>
              {doctors.map(d => <option key={d.id} value={d.id}>{d.name} — {d.specialization}</option>)}
            </select>
            <input value={patientName} onChange={e=>setPatientName(e.target.value)} placeholder="Patient name" className="w-full p-2 border rounded" />
            <input value={patientEmail} onChange={e=>setPatientEmail(e.target.value)} placeholder="Patient email" className="w-full p-2 border rounded" />
            <input value={date} onChange={e=>setDate(e.target.value)} placeholder="YYYY-MM-DDTHH:MM:SS" className="w-full p-2 border rounded" />
            <button onClick={book} className="px-4 py-2 bg-blue-600 text-white rounded">Book</button>
          </div>
        </div>
      </div>
    </Layout>
  )
}
