import React from 'react'
import { useRouter } from 'next/router'
export default function Layout({ children }: { children: React.ReactNode }) {
  const router = useRouter()
  const logout = () => {
    localStorage.removeItem('token')
    router.push('/')
  }
  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow p-4 flex justify-between">
        <h2 className="text-lg font-semibold">Front Desk</h2>
        <div>
          <button onClick={logout} className="px-3 py-1 border rounded">Logout</button>
        </div>
      </header>
      <main className="p-6">{children}</main>
    </div>
  )
}
